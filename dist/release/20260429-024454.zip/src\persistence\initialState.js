(function (global) {
  'use strict';

  function createInitialTutorialState() {
    var tutorialSteps = global.Game && global.Game.TutorialSteps;
    if (tutorialSteps && typeof tutorialSteps.buildInitialTutorialState === 'function') {
      return tutorialSteps.buildInitialTutorialState();
    }

    return {
      version: 5,
      disabled: false,
      completed: false,
      currentStepId: 'starter_tank',
      steps: {
        starter_tank: {
          completed: false,
          dismissed: false,
          bubbleOpen: true,
        },
        second_tank: {
          completed: false,
          dismissed: false,
          bubbleOpen: true,
        },
        merge_tank: {
          completed: false,
          dismissed: false,
          bubbleOpen: true,
        },
      },
    };
  }

  function createInitialState(options) {
    var opts = options || {};
    var reason = opts.reason === 'new_game' ? 'new_game' : 'boot';
    var maxLevel = Number.isFinite(opts.maxLevel) ? Math.floor(opts.maxLevel) : 60;

    // --- Fence segments с repairCount ---
    var fenceSegments = [];
    if (global.Game && global.Game.FenceLayout && typeof global.Game.FenceLayout.buildSquareFenceSegments === 'function') {
      var segments = global.Game.FenceLayout.buildSquareFenceSegments({});
      for (var i = 0; i < segments.length; i++) {
        var seg = Object.assign({}, segments[i]);
        seg.repairCount = 0;
        fenceSegments.push(seg);
      }
    }
    // ---
    return {
      coins: 40,
      kills: 0,
      totalDamageDealtRaw: 0,
      zombieWaveAtkMult: 1,
      damagePointsSpent: 0,
      fenceLevel: 1,
      fenceRepairCount: 0,
      cells: [],
      boardRect: { x: 0, y: 0, w: 0, h: 0 },
      zombies: [],
      projectiles: [],
      impacts: [],
      decals: [],
      particles: [],
      damageNumbers: [],
      drones: [],
      decors: [],
      wallDecors: [],
      mapSeeds: {
        stampsSeed: null,
        decorSeed: null,
      },
      nextZombieRenderOrder: 1,
      fenceSegments: fenceSegments,
      fenceSegmentsMeta: null,
      savedFenceState: null,
      crate: null,
      nextCrateAt: 0,
      dragging: null,
      boostUntil: 0,
      empUntil: 0,
      activeEffects: {
        attackUntil: 0,
        speedUntil: 0,
        economyUntil: 0,
      },
      supercomputer: {
        computerLevel: 0,
        xp: 0,
        xpToNext: 50,
        maxLevel: maxLevel,
        hp: 920,
        maxHp: 920,
        armorFlat: 2,
        x: 0,
        y: 0,
        offsetY: 64,
        state: 'idle',
        animElapsedSec: 0,
        glitchLoopsRemaining: 0,
        glitchCooldownUntil: 0,
        wantsBuildTank: false,
        pendingBuildTank: false,
        eventShown40: false,
        eventShown50: false,
        eventShown60: false,
      },
      player: {
        talentPoints: 0,
        damagePoints: 0,
        talentsApplied: [],
        talentsPending: [],
        talentsVersion: 2,
        talentsV2: {
          ranksById: {},
          freePoints: 0,
        },
        freeTalentPointsV2: 0,
        activeCooldowns: [0, 0, 0],
        cannonUpgradesApplied: Array(maxLevel).fill(0),
        fenceUpgradesApplied: Array(60).fill(0),
        mods: null,
        modsDirty: true,
        eventShown40: false,
        eventShown50: false,
        eventShown60: false,
      },
      endgameVisuals: false,
      maxTankLevelAchieved: 1,
      runtimeMaxTankLevelAchieved: 1,
      currentFenceTierApplied: 1,
      buyCounts: {},
      buyPrices: {},
      achievements: {
        unlocked: {},
        popupQueue: [],
        rewarded: {},
        deferredRewards: [],
        totalPurchased: 0,
        totalMerges: 0,
        totalManualFenceRepairs: 0,
        totalModifierTechUnlocks: 0,
        totalDroneAcquisitions: 0,
        totalNoRepairAttackWaveStreak: 0,
        totalMoneyEarned: 0,
        totalPerfectFenceWaves: 0,
        totalHangarMasterLevel: 0,
        totalMaxTankLevel: 0,
        completedModifierTechs: {},
      },
      stats: {
        tanksMergedCount: 0,
        tanksBoughtCount: 0,
        manualFenceRepairsCount: 0,
        modifierTechUnlocksCount: 0,
        droneAcquisitionsCount: 0,
        noRepairAttackWaveStreakCount: 0,
        moneyEarnedCount: 0,
        perfectFenceWavesCount: 0,
        hangarMasterLevelCount: 0,
        maxTankLevelCount: 0,
      },
      ui: {
        talentsOpen: false,
        talentBranch: 0,
        levelReward: null,
        levelRewardTimer: 0,
        menuOpen: true,
        toast: {
          active: null,
          queue: [],
        },
        unlockFx: {
          autoMergeUntilMs: 0,
          bulkBuyUntilMs: 0,
        },
      },
      flags: {
        preRetryAutosavedThisCritical: false,
        wasCritical: false,
        preRetrySaveFailed: false,
      },
      selectedHangarCellIndex: null,
      isDismantleMode: false,
      selectedTankIds: [],
      tutorial: createInitialTutorialState(),
      hangarCells: null,
      playerChips: [],
      productionLine: {
        killsTracked: 0,
        boxesProduced: 0,
        progress: 0,
        storageSlots: 9,
        storage: [],
        conveyorAnimTime: 0,
        firstNewGameBoxGuaranteedPending: reason === 'new_game',
      },
    };
  }

  global.Game = global.Game || {};
  global.Game.InitialState = {
    createInitialState: createInitialState,
  };
})(typeof window !== 'undefined' ? window : this);
